# Todo list

_\( managed using [todo-md](https://github.com/Hypercubed/todo-md) \)_

- [ ] Support gradiants
- [ ] Drag and drop
- [ ] Validate data types
- [ ] Autoscale chart?
- [ ] Per chart options
- [ ] Chart description and examples
- [ ] Support JSON data